AMARA MOON — STATIC SITE BUNDLE
==============================

HOW TO UPLOAD
-------------
Upload everything INSIDE this folder (not the folder itself) into your web
root — usually public_html on cPanel.

Include the .htaccess file. FTP clients hide dotfiles by default, so switch on
"show hidden files" or the security headers, 404 page and caching rules will be
left behind.

WHAT WORKS
----------
Every page: home, offerings, schedule, stay, gallery, contact, work with us.
All photos, styling and navigation. Google-facing pieces too — sitemap.xml,
robots.txt, canonical tags and structured data.

WHAT LIVES ON THE APP INSTEAD
-----------------------------
Shared hosting can only send files; it cannot run code, hold a database or
talk to Stripe. So these stay on https://amara-moon.vercel.app, and the
uploaded pages link across to them:

  - Session and sauna booking with card payment
  - Booking confirmation pages
  - The contact and "work with us" forms

Guests can still book and pay — they cross to the booking site to do it. The
contact page here also offers WhatsApp, email and phone directly.

IMPORTANT: keep https://amara-moon.vercel.app online. If it goes
away, those links break. Nothing on the uploaded site can replace them.

CABIN BOOKINGS
--------------
Unaffected. They were always handled by the listing platforms, and those links
work anywhere.

UPDATING THE SITE
-----------------
Re-run the export from the project folder, then re-upload. Editing the HTML in
here by hand works, but the next export overwrites it — change the source
instead. Needs Node 20+ and pnpm; run "pnpm install" once on a new machine.
No database or Stripe keys needed for this.

  NEXT_PUBLIC_APP_ORIGIN=https://amara-moon.vercel.app pnpm export
